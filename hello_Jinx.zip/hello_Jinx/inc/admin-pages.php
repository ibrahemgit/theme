
<?php 

add_action('admin_menu', 'custom_settings_page');

function custom_settings_page() {
    add_menu_page(
        'صفحة الإعدادات',
        'الإعدادات الخاصة',
        'manage_options',
        'custom-settings',
        'custom_settings_page_html',
        'dashicons-admin-generic',
        100
    );
}

function custom_settings_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['custom_settings_save'])) {
        update_option('custom_email', sanitize_email($_POST['custom_email']));
        update_option('custom_phone', sanitize_text_field($_POST['custom_phone']));
        update_option('custom_whatsapp', sanitize_text_field($_POST['custom_whatsapp']));
        echo '<div class="updated"><p>تم حفظ الإعدادات بنجاح.</p></div>';
    }

    $custom_email = get_option('custom_email', '');
    $custom_phone = get_option('custom_phone', '');
    $custom_whatsapp = get_option('custom_whatsapp', '');

    echo '<div class="wrap">';
    echo '<h1>الإعدادات الخاصة</h1>';
    echo '<form method="post">';
    echo '<table class="form-table">';
    echo '<tr><th scope="row"><label for="custom_email">البريد الإلكتروني</label></th>';
    echo '<td><input name="custom_email" type="email" id="custom_email" value="' . esc_attr($custom_email) . '" class="regular-text"></td></tr>';
    echo '<tr><th scope="row"><label for="custom_phone">رقم الهاتف</label></th>';
    echo '<td><input name="custom_phone" type="text" id="custom_phone" value="' . esc_attr($custom_phone) . '" class="regular-text"></td></tr>';
    echo '<tr><th scope="row"><label for="custom_whatsapp">رقم الواتساب</label></th>';
    echo '<td><input name="custom_whatsapp" type="text" id="custom_whatsapp" value="' . esc_attr($custom_whatsapp) . '" class="regular-text"></td></tr>';
    echo '</table>';
    echo '<p><input type="submit" name="custom_settings_save" class="button-primary" value="حفظ الإعدادات"></p>';
    echo '</form>';
    echo '</div>';
}



#############################
####  Admin_scripts
#############################


function ib_admin_script($hook){
    if(str_contains( $hook , 'toplevel_page_contact' ) || str_contains( $hook , 'profile.php' ) || str_contains( $hook , 'user-edit.php' ) || str_contains( $hook , 'post-new.php' ) || str_contains( $hook , 'post.php' ) || str_contains( $hook , 'term.php' ) || str_contains( $hook , 'edit-tags.php' ) || str_contains( $hook , 'toplevel_page_second_theme_options_page' )|| str_contains( $hook , 'toplevel_page_theme_filter_option_page' )){
        $theme_version = wp_get_theme()->get('Version');
            wp_enqueue_style('adminscripts', get_template_directory_uri() . '/assets/admin/adminstyle.css', array(), $theme_version);
            wp_enqueue_script('adminscripts', get_template_directory_uri() . '/assets/admin/admin.js', array('jquery'), $theme_version, true);
            wp_enqueue_media();
            wp_enqueue_editor();
            wp_localize_script('adminscripts', 'ajax_object', array(
                'ajax_url' => admin_url('admin-ajax.php'),
            ));
        }else{
        return;
    }
}
add_action( 'admin_enqueue_scripts', 'ib_admin_script' );




// إضافة صفحة Admin جديدة
function custom_admin_menu() {
    add_menu_page(
        'Click Counts', // عنوان الصفحة
        'Click Counts', // النص الذي يظهر في القائمة
        'manage_options', // الصلاحيات المطلوبة
        'click-counts', // URL Slug
        'display_click_counts_page_and_posts', // الدالة التي تعرض محتوى الصفحة
        'dashicons-chart-bar', // الأيقونة التي ستظهر بجانب القائمة
        6 // ترتيب القائمة
    );
}
add_action('admin_menu', 'custom_admin_menu');


// دالة لعرض محتوى الصفحة والمقالات
function display_click_counts_page_and_posts() {
    // استعراض الصفحات والمقالات
    $posts = get_posts(array(
        'post_type' => array('page', 'post'), // استعراض الصفحات والمقالات
        'posts_per_page' => -1 // جلب كل المنشورات
    ));
    
    ?>
    <div class="wrap">
        <h1>عدد الضغطات على الأزرار لكل صفحة أو مقال</h1>
        <table class="widefat fixed">
            <thead>
                <tr>
                    <th>الصفحة / المقالة</th>
                    <th>Submit Button</th>
                    <th>WhatsApp Button</th>
                    <th>Phone Button</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($posts as $post) {
                    $post_id = $post->ID;
                    ?>
                    <tr>
                        <td><?php echo get_the_title($post_id); ?></td>
                        <td><?php echo get_option('click_count_' . $post_id . '_submit', 0); ?></td>
                        <td><?php echo get_option('click_count_' . $post_id . '_whatsapp', 0); ?></td>
                        <td><?php echo get_option('click_count_' . $post_id . '_phone', 0); ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}
